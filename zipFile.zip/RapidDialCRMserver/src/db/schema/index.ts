// Table definitions and types
export * from "./prospects";
export * from "./field-reps";
export * from "./appointments";
export * from "./call-history";
export * from "./stakeholders";
export * from "./users";
export * from "./user-territories";
export * from "./user-professions";
export * from "./specialty-colors";
export * from "./call-outcomes";
export * from "./issues";
